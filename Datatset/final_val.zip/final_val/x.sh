#!/bin/bash

# Loop through all folders in the current directory
for dir in pos_*; do
  # Check if it is a directory
  if [ -d "$dir" ]; then
    # Extract folder name without the "pos_" prefix
    new_name="${dir#pos_}"
    # Rename the folder
    mv "$dir" "$new_name"
  fi
done

